// Get config.json file
$.getJSON( "../assets/config.json", function( data ) {  
    var configData = data;
});
